from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import RegisterUserView, CreateItemView, ReadItemView, UpdateItemView, DeleteItemView

urlpatterns = [
    # User registration endpoint
    path('api/register/', RegisterUserView.as_view(), name='register'),

    # JWT authentication endpoints
    path('api/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    # CRUD operations
    path('api/items/', CreateItemView.as_view(), name='create_item'),  # Changed to a dedicated path for creating
    path('api/items/<int:item_id>/', ReadItemView.as_view(), name='read_item'),  # For reading
    path('api/items/<int:item_id>/update', UpdateItemView.as_view(), name='update_item'),  # Updated to a separate path
    path('api/items/<int:item_id>/delete/', DeleteItemView.as_view(), name='delete_item'),  # Updated to a separate path
]
