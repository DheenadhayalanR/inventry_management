import redis  # Import the redis module
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from .models import Item  # Adjust this import based on your app structure

User = get_user_model()

class InventoryAPITests(APITestCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.redis_client = redis.Redis(host='127.0.0.1', port=6379, db=0)
        cls.redis_client.ping()  # Check Redis is running

    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            email='testuser@example.com',
            password='securepassword123'
        )
        self.login_url = reverse('token_obtain_pair')
        self.items_url = reverse('create_item')  # Adjust based on your URL configuration

    def test_user_registration(self):
        """Test user registration."""
        url = reverse('register')
        data = {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'securepassword456'
        }
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.count(), 2)

    def test_user_login(self):
        """Test user login and token retrieval."""
        data = {
            'username': 'testuser',
            'password': 'securepassword123'
        }
        response = self.client.post(self.login_url, data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)

    # Add other test methods here...

